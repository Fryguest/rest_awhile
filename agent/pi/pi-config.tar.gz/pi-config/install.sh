#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PI_DIR="${HOME}/.pi/agent"

echo "[1/3] Copying base configs..."
mkdir -p "${PI_DIR}"
for f in "${SCRIPT_DIR}"/configs/*; do
  [ -f "$f" ] || continue
  cp "$f" "${PI_DIR}/$(basename "$f")"
  echo "  $(basename "$f")"
done

echo "[2/3] Installing extensions..."
EXT_JSON="${SCRIPT_DIR}/extensions/extensions.json"
if [ -f "${EXT_JSON}" ]; then
  count=$(python3 -c "import json; print(len(json.load(open('${EXT_JSON}'))))")
  for i in $(seq 0 $((count - 1))); do
    name=$(python3 -c "import json; print(json.load(open('${EXT_JSON}'))[$i]['name'])")
    source=$(python3 -c "import json; print(json.load(open('${EXT_JSON}'))[$i]['source'])")
    echo "  Installing ${name} from ${source}..."
    pi install "${source}"
    if [ -d "${SCRIPT_DIR}/extensions/${name}" ]; then
      mkdir -p "${PI_DIR}/extensions/${name}"
      cp -r "${SCRIPT_DIR}/extensions/${name}/." "${PI_DIR}/extensions/${name}/"
      echo "  Copied ${name} configs"
    fi
  done
else
  echo "  No extensions.json found, skipping"
fi

echo "[3/3] Done."
echo ""
echo "Start pi and run /login to authenticate."
